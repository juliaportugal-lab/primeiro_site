create database biblioteca;
use biblioteca;
create table livros(
idivro int primary key auto_increment,
Nome_do_livro varchar(100), 
autor varchar(100),
 ano_de_lançamento date,
editora varchar(100));