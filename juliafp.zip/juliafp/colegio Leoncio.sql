create database colegioLeoncio;
use database colegioLeoncio;